#!/bin/bash

echo "create at sample file"
touch /tmp/sample
